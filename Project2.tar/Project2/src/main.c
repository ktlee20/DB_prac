#include <stdio.h>
#include <stdlib.h>
#include "FileIndexManager.h"
#include "defines.h"
#include "globals.h"


FILE * default_file;
Page * header;
Page * rootpage;
pagenum_t totalp;
pagenum_t currentp;

int main(int argc, char * argv[])
{
	open_db("default.db");
	insert(1,"lee");

	return 0;
}
